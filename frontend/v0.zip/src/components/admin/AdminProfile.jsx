import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminProfile = () => {
  const [admin, setAdmin] = useState(null);
  const [users, setUsers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    // Fetch admin profile
    axios.get('/admin-api/profile')
      .then(response => setAdmin(response.data))
      .catch(error => setError('Failed to fetch admin profile'));

    // Fetch users
    axios.get('/admin-api/users')
      .then(response => setUsers(response.data))
      .catch(error => setError('Failed to fetch users'));
  }, []);

  const handleBlockUnblock = (userId, blocked) => {
    axios.put(`/admin-api/block-unblock/${userId}`, { blocked })
      .then(response => {
        setUsers(users.map(user => user._id === userId ? response.data.payload : user));
      })
      .catch(error => setError('Failed to update user status'));
  };

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="container">
      {admin && (
        <div className="text-center my-4">
          <h1>Admin Profile</h1>
          <p>Name: {admin.name}</p>
          <p>Email: {admin.email}</p>
        </div>
      )}
      <h2 className="text-center my-4">Users</h2>
      <ul className="list-group">
        {Array.isArray(users) && users.map(user => (
          <li key={user._id} className="list-group-item d-flex justify-content-between align-items-center">
            {user.name} ({user.email}) - {user.role}
            <button onClick={() => handleBlockUnblock(user._id, !user.blocked)} className="btn btn-sm btn-warning">
              {user.blocked ? 'Unblock' : 'Block'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminProfile;
