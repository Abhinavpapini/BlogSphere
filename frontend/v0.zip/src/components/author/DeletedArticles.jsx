import { useState, useEffect } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@clerk/clerk-react'

function DeletedArticles() {
  const [articles, setArticles] = useState([])
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const { getToken } = useAuth()

  async function getDeletedArticles() {
    const token = await getToken()
    let res = await axios.get('http://localhost:3000/author-api/deleted-articles', {
      headers: {
        Authorization: `Bearer ${token}`
      }
    })
    if (res.data.message === 'articles') {
      setArticles(res.data.payload)
      setError('')
    } else {
      setError(res.data.message)
    }
  }

  async function restoreArticle(articleId) {
    const token = await getToken()
    try {
      const res = await axios.put(`http://localhost:3000/author-api/articles/${articleId}`, { isArticleActive: true }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      if (res.data.message === 'article deleted or restored') {
        setArticles(articles.filter(article => article.articleId !== articleId))
      } else {
        setError(res.data.message)
      }
    } catch (error) {
      setError('Failed to restore article')
    }
  }

  useEffect(() => {
    getDeletedArticles()
  }, [])

  return (
    <div className='container'>
      {error.length !== 0 && <p className='display-4 text-center mt-5 text-danger'>{error}</p>}
      <div className='row row-cols-1 row-cols-sm-2 row-cols-md-3 '>
        {articles.map((articleObj) => (
          <div className='col' key={articleObj.articleId}>
            <div className="card h-100">
              <div className="card-body">
                <h5 className='card-title'>{articleObj.title}</h5>
                <p className='card-text'>{articleObj.content.substring(0, 80) + "...."}</p>
                <button className='custom-btn btn-4' onClick={() => restoreArticle(articleObj.articleId)}>
                  Restore
                </button>
              </div>
              <div className="card-footer">
                <small className="text-body-secondary">Last updated on {articleObj.dateOfModification}</small>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default DeletedArticles
